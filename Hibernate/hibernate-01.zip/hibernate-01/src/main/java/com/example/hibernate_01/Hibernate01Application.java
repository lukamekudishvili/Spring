package com.example.hibernate_01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hibernate01Application {

	public static void main(String[] args) {
		SpringApplication.run(Hibernate01Application.class, args);
	}

}
